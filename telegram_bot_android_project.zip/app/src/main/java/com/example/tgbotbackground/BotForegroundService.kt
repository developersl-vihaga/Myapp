package com.example.tgbotbackground

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONObject
import java.net.*

class BotForegroundService: Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val botToken = "7747068384:AAEcjBAH-4vVMEzJtmKeozOZjR7J3vOGvBo"
    private val adminIds = setOf<Long>() // <- add admin IDs

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, notif())
        scope.launch { loop() }
        return START_STICKY
    }

    private fun notif(): Notification {
        val ch = NotificationChannel("tgch","TG Bot",NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        return NotificationCompat.Builder(this,"tgch")
            .setContentTitle("Telegram Bot Running")
            .setSmallIcon(android.R.drawable.stat_sys_sync)
            .build()
    }

    private suspend fun loop() {
        val client = OkHttpClient()
        var offset = 0L
        while (isActive) {
            try {
                val url = "https://api.telegram.org/bot$botToken/getUpdates?timeout=30&offset=$offset"
                val resp = client.newCall(Request.Builder().url(url).build()).execute()
                val body = resp.body?.string() ?: ""
                val arr = JSONObject(body).optJSONArray("result") ?: continue
                for (i in 0 until arr.length()) {
                    val up = arr.getJSONObject(i)
                    offset = up.getLong("update_id")+1
                    handle(up, client)
                }
            } catch (e: Exception) { delay(5000) }
        }
    }

    private fun handle(up: JSONObject, client: OkHttpClient) {
        val msg = up.optJSONObject("message") ?: return
        val text = msg.optString("text","")
        val chatId = msg.getJSONObject("chat").getLong("id")
        val from = msg.getJSONObject("from").getLong("id")
        if (!adminIds.contains(from)) return

        if (text.startsWith("/getip")) {
            val local = getLocalIp()
            val public = getPublicIp(client)
            send(client, chatId, "Local: $local\nPublic: $public")
        }
    }

    private fun send(c: OkHttpClient, chat: Long, text: String) {
        val req = Request.Builder()
            .url("https://api.telegram.org/bot$botToken/sendMessage")
            .post(FormBody.Builder().add("chat_id","$chat").add("text",text).build())
            .build()
        c.newCall(req).execute()
    }

    private fun getLocalIp(): String {
        try {
            val en = NetworkInterface.getNetworkInterfaces()
            while (en.hasMoreElements()) {
                val intf = en.nextElement()
                val addrs = intf.inetAddresses
                while (addrs.hasMoreElements()) {
                    val a = addrs.nextElement()
                    if (!a.isLoopbackAddress && a is Inet4Address) return a.hostAddress
                }
            }
        } catch (e: Exception) {}
        return "unknown"
    }

    private fun getPublicIp(c: OkHttpClient): String {
        return try {
            c.newCall(Request.Builder().url("https://api.ipify.org").build())
                .execute().body?.string()?.trim() ?: "unknown"
        } catch (e: Exception) { "unknown" }
    }

    override fun onBind(p0: Intent?): IBinder? = null
}
