package com.example.tgbotbackground

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import androidx.core.content.ContextCompat

class MainActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val svc = Intent(this, BotForegroundService::class.java)
        ContextCompat.startForegroundService(this, svc)
        finish()
    }
}
