package com.example.tgbotbackground

import android.content.*
import androidx.core.content.ContextCompat

class BootReceiver: BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) {
            ContextCompat.startForegroundService(c, Intent(c, BotForegroundService::class.java))
        }
    }
}
